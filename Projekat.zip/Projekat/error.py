import tkinter as tk
from tkinter import messagebox

window = tk.Tk()
messagebox.showinfo("Elrad WSS", "Upisati u tabelu koliko smo komada odradili danas")
window.mainloop()
