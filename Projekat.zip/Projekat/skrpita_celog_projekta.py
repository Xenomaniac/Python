import os
from datetime import datetime
from datetime import date, timedelta

trenutno = "trenutno.txt"
local_dt = datetime.now()
filename = "libovi.xls"
lib = input("Unesite vas lib:")
kolicina = "kolicina.xml"
trenutna = str(input("Da li pocinjete nov nalog ?  "))




def create_folder(folder_name):
    try:
        os.makedirs(folder_name)
        print(f"Folder '{folder_name}' je uspešno napravljen.")
    except FileExistsError:
        print(f"Folder '{folder_name}' već postoji.")

def get_user_input():
    try:
        user_input = int(input("Unesite obrađenu količinu: "))
        return user_input
    except ValueError:
        print("Nepravilan unos, unesite ispravnu količinu.")
        return None

if __name__ == "__main__":
    user_folder_name = input("Unesite broj proizvoda: ")
    create_folder(user_folder_name)
    user_second_folder_name = input("Unesite broj radnog naloga: ")
    create_folder(os.path.join(user_folder_name, user_second_folder_name))
    user_file_name = user_second_folder_name
    user_value = get_user_input()
    if user_value is not None:
        with open(f"{user_folder_name}/{user_second_folder_name}/{user_file_name}.txt", "w") as file:
            file.write(str(user_value))
        print(f"Odradili ste: {user_value}.")
        

if trenutna == 'da':
    with open (f"{user_folder_name}/{user_second_folder_name}/trenutno.txt", "w") as file:
        file.write(str("0"))
else:
    prethodna = int(input("Unesite koliko je bilo odradjeno kad ste poceli:  "))
    with open (f"{user_folder_name}/{user_second_folder_name}/ trenutno.txt", "w") as file:
        file.write(str(prethodna))

with open(f"{user_folder_name}/{user_second_folder_name}/ libovi.xls", 'a') as fp:
    fp.write(f"Lib: {lib}\n")
    fp.write(f"Odradjena kolicina: {user_value}\n")
    fp.write(f"{local_dt}\n")

pitanje = input("Da li vas zanima izvoz i kolicina  ?")

if pitanje == 'da':
    sifra = input("Unesite sifru: ")
    if sifra =='Elrad WSS':
        def calculate_remaining_days(start_date, end_date):
            total_days = (end_date - start_date).days
            
            num_sundays = sum(1 for i in range(total_days + 1) if (start_date + timedelta(days=i)).weekday() == 6)
            
            remaining_days = total_days - num_sundays
            return remaining_days

           
        kolicina = int(input("Unesite kolicinu narudzbine: "))
        smena = user_value + 1
        testovi = int(input("Unesite na koliko testova testirate ovaj proizvod: "))
        mesec = int(input("Unesite mesec isporuke: "))
        dan = int(input("Unesite dan isporuke: "))  
        filename = f"{user_folder_name}.xls"



        danas = date.today()
        isporuka = date(danas.year, mesec, dan)
        ostalo_dana = calculate_remaining_days(danas, isporuka)
        dnevna = smena * testovi * 2
        nocna = smena * testovi * 3
        samo_dan = dnevna * ostalo_dana
        fali = kolicina  - samo_dan
        treca = nocna * ostalo_dana
        fali1 = kolicina - treca
        
        if trenutna =='da':
            print("Continue")
        else:
            with open("exec.py") as file:
                exec(file.read())




        print (f"Proizvod {user_folder_name} ako bi radili bez trece smene:")
        if fali > 0:
            visak = abs(fali) / smena
            print(f"Fali nam {visak} smena")
        else:
            visak = abs(fali) / smena
            print(f"Stizemo isporuku na vreme, cak imamo {abs(visak)} visak smena")

        print (f"Proizvod {user_folder_name} ako bi radili sa trecom smenom:")

        if fali1 > 0:
            visak1 = abs(fali1) / smena
            print(f"Fali nam {visak1} smena")
        else:
            visak1 = abs(fali1) / smena
            print(f"Stizemo isporuku na vreme, cak imamo {abs(visak1)} visak smena")
        print(f"Preostalo dana do isporuke: {ostalo_dana}")


        with open(filename, 'a') as fp:        
            fp.write(f"Proizvod: {user_folder_name}\n")
            fp.write(f"Nalog: {user_second_folder_name}\n")
            fp.write(f"Preostalo dana do isporuke: {ostalo_dana}\n")    
            fp.write(f"Proizvod: {user_folder_name}\n")
            fp.write(f"Bez trece smene nam fali: {fali}\n")    
            fp.write(f"Sa trecom smenom nam fali: {fali1} (ako je rezultat u minusu to je visak kolicina.)\n")
            fp.write(f"Kolicina: {kolicina}\n")
            fp.write(f"Isporuka je: {dan}/{mesec}(days/months)\n")

    else:
                print("Sifra je pogresna  \U0001F611")        

else:
    print("Hvala sto ste uneli podatke! \U0001F929")




