import os
from datetime import datetime

trenutno = "trenutno.txt"
local_dt = datetime.now()
filename = "libovi.xls"
lib = input("Unesite vas lib:")
kolicina = "kolicina.xml"
trenutna = str(input("Da li pocinjete nov nalog ?  "))




def create_folder(folder_name):
    try:
        os.makedirs(folder_name)
        print(f"Folder '{folder_name}' je uspešno napravljen.")
    except FileExistsError:
        print(f"Folder '{folder_name}' već postoji.")

def get_user_input():
    try:
        user_input = int(input("Unesite obrađenu količinu: "))
        return user_input
    except ValueError:
        print("Nepravilan unos, unesite ispravnu količinu.")
        return None

if __name__ == "__main__":
    user_folder_name = input("Unesite broj proizvoda: ")
    create_folder(user_folder_name)
    user_second_folder_name = input("Unesite broj radnog naloga: ")
    create_folder(os.path.join(user_folder_name, user_second_folder_name))
    user_file_name = user_second_folder_name
    user_value = get_user_input()
    if user_value is not None:
        with open(f"{user_folder_name}/{user_second_folder_name}/{user_file_name}.txt", "w") as file:
            file.write(str(user_value))
        print(f"Odradili ste: {user_value}.")
        

if trenutna == 'da':
    with open (f"{user_folder_name}/{user_second_folder_name}/trenutno.txt", "w") as file:
        file.write(str("0"))
else:
    prethodna = int(input("Unesite koliko je bilo odradjeno kad ste poceli:  "))
    with open (f"{user_folder_name}/{user_second_folder_name}/ trenutno.txt", "w") as file:
        file.write(str(prethodna))

with open(f"{user_folder_name}/{user_second_folder_name}/ libovi.xls", 'a') as fp:
    fp.write(f"Lib: {lib}\n")
    fp.write(f"Odradjena kolicina: {user_value}\n")
    fp.write(f"{local_dt}\n")


with open("process.py") as file:
    exec(file.read())


