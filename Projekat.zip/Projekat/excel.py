import pandas as pd
import os

# Function to process each Excel file
def process_excel_file(file_path):
    try:
        df = pd.read_excel(file_path, sheet_name="Testergebnis")
        return df
    except Exception as e:
        print(f"Error processing file {file_path}: {e}")
        return pd.DataFrame()  # Return an empty DataFrame in case of error

# Folder containing the Excel files
folder_path = r"C:\Users\strahim\Desktop\SVE\Projekat\results"  # Update this path

# List to store results
results = []

# Loop through all Excel files in the folder
for filename in os.listdir(folder_path):
    if filename.endswith(".xlsx"):
        file_path = os.path.join(folder_path, filename)
        df = process_excel_file(file_path)
        if not df.empty:
            results.append(df)

# Concatenate all results into a single DataFrame
if results:
    results_df = pd.concat(results, ignore_index=True)
    # Save the results to a new Excel file
    results_df.to_excel("combined_results.xlsx", index=False)
    print("Results have been saved to 'combined_results.xlsx'")
else:
    print("No valid data found in the specified folder.")
