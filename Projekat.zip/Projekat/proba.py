import pandas as pd

df = pd.read_excel("narudzbine.xlsx","datum ")
datum = df['datum']

print(datum)

