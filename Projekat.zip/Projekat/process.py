# process.py

def load_and_process():
    try:
        with open(f"{user_folder_name}/{user_second_folder_name}/ trenutno.txt", "r+") as file:
            quantity = int(file.read().strip())
            ukupno = int(quantity) + int(user_value)
            print(f"Processed result: {ukupno}")
            print(f"Processed user_value: {user_value}")
            print(f"Processed quantity: {quantity}")
            file.write(str(ukupno))
            
    except FileNotFoundError:
        print("Nismo pronasli ulazne podatke, pokrenite prvo prvu skriptu molim.")

if __name__ == "__main__":
    load_and_process()
