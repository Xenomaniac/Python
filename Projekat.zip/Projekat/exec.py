            with open (f"{user_folder_name}/{user_second_folder_name}/trenutno.txt", "a") as file:
                prethodna = int(file.read().strip())
                ukupno = int(quantity) + int(user_value)
                mogucnost = samo_dan + prethodna            
                mogucnost1 = treca + prethodna
                fali = kolicina  - mogucnost                
                fali1 = kolicina  - mogucnost1
                print (f"Proizvod {user_folder_name} ako bi radili bez trece smene:")
                if fali > 0:
                    visak = abs(fali) / smena
                    print(f"Fali nam {visak} smena")
                else:
                    visak = abs(fali) / smena
                    print(f"Stizemo isporuku na vreme, cak imamo {abs(visak)} visak smena")

                    print (f"Proizvod {user_folder_name} ako bi radili sa trecom smenom:")
                if fali1 > 0:
                    visak1 = abs(fali1) / smena
                    print(f"Fali nam {visak1} smena")
                else:
                    visak1 = abs(fali1) / smena
                    print(f"Stizemo isporuku na vreme, cak imamo {abs(visak1)} visak smena")
                print(f"Preostalo dana do isporuke: {ostalo_dana}")



---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
with open(f"{user_folder_name}/{user_second_folder_name}/trenutno.txt", "r") as file:
    prethodna = int(file.read().strip())
    ukupno = int(quantity) + int(user_value)
    mogucnost = samo_dan + prethodna
    mogucnost1 = treca + prethodna
    fali = kolicina - mogucnost
    fali1 = kolicina - mogucnost1

print(f"Proizvod {user_folder_name} ako bi radili bez trece smene:")
if fali > 0:
    visak = abs(fali) / smena
    print(f"Fali nam {visak} smena")
else:
    visak = abs(fali) / smena
    print(f"Stizemo isporuku na vreme, cak imamo {abs(visak)} visak smena")

print(f"Proizvod {user_folder_name} ako bi radili sa trecom smenom:")
if fali1 > 0:
    visak1 = abs(fali1) / smena
    print(f"Fali nam {visak1} smena")
else:
    visak1 = abs(fali1) / smena
    print(f"Stizemo isporuku na vreme, cak imamo {abs(visak1)} visak smena")

print(f"Preostalo dana do isporuke: {ostalo_dana}")
