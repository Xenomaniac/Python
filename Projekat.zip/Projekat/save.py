from datetime import date, timedelta

def calculate_remaining_days(start_date, end_date):
    total_days = (end_date - start_date).days
    
    num_sundays = sum(1 for i in range(total_days + 1) if (start_date + timedelta(days=i)).weekday() == 6)
    
    remaining_days = total_days - num_sundays
    return remaining_days

proizvod = int(input("Unesite broj proizvoda: "))
nalog = int(input("Unesite radni nalog proizvoda: "))
kolicina = int(input("Unesite kolicinu narudzbine: "))
smena = int(input("Unesite kolicinu koja se odradi za smenu: "))
testovi = int(input("Unesite na koliko testova testirate ovaj proizvod: "))
trenutna = int(input("Unesite trenutnu kolicinu: "))
mesec = int(input("Unesite mesec isporuke: "))
dan = int(input("Unesite dan isporuke: "))  
filename = f"{proizvod}.xls"


danas = date.today()
isporuka = date(danas.year, mesec, dan)
ostalo_dana = calculate_remaining_days(danas, isporuka)
dnevna = smena * testovi * 2
nocna = smena * testovi * 3
samo_dan = dnevna * ostalo_dana
mogucnost = samo_dan + trenutna
fali = kolicina  - mogucnost
treca = nocna * ostalo_dana
mogucnost1 = treca + trenutna
fali1 = kolicina - mogucnost1


print (f"Proizvod {proizvod} ako bi radili bez trece smene:")
if fali > 0:
    visak = abs(fali) / smena
    print(f"Fali nam {visak} smena")
else:
    visak = abs(fali) / smena
    print(f"Stizemo isporuku na vreme, cak imamo {abs(visak)} visak smena")

print (f"Proizvod {proizvod} ako bi radili sa trecom smenom:")

if fali1 > 0:
    visak1 = abs(fali1) / smena
    print(f"Fali nam {visak1} smena")
else:
    visak1 = abs(fali1) / smena
    print(f"Stizemo isporuku na vreme, cak imamo {abs(visak1)} visak smena")
print(f"Preostalo dana do isporuke: {ostalo_dana}")


with open(filename, 'a') as fp:        
    fp.write(f"Proizvod: {proizvod}\n")
    fp.write(f"Nalog: {nalog}\n")
    fp.write(f"Preostalo dana do isporuke: {ostalo_dana}\n")    
    fp.write(f"Proizvod: {proizvod}\n")
    fp.write(f"Bez trece smene nam fali: {fali}\n")    
    fp.write(f"Sa trecom smenom nam fali: {fali1} (ako je rezultat u minusu to je visak kolicina.)\n")
    fp.write(f"Kolicina: {kolicina}\n")
    fp.write(f"Odradjena kolicina: {trenutna}\n")
    fp.write(f"Isporuka je: {dan}/{mesec}(days/months)\n")



