import pandas as pd

# Load the Excel file
df = pd.read_excel("high.xlsx", "Pareto")

# Find all rows where the 'Customer' column contains 'Schaerer'
schaerer_rows = df[df['Customer'].str.contains('Schaerer', na=False)]

# Check if any rows were found
if not schaerer_rows.empty:
    # Loop through each row and print the 'Customer', 'Quantity_2024', and 'Artikel' values
    for _, row in schaerer_rows.iterrows():
        kupac = row['Customer']
        kolicina = row['Quantity_2024']
        artikel = row['Artikel']
        
        # If 'Artikel' is blank, print 0
        if pd.isna(artikel):
            artikel = 0

        print(f"Artikel: {artikel}")
        print(f"Customer: {kupac}")
        print(f"Quantity: {kolicina}")

else:
    print("No customers with the name 'Schaerer' found.")
