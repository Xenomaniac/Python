import pandas as pd

df = pd.read_excel("high.xlsx","Pareto")
kupac = df.iloc[3]['Customer']
kolicina = df.iloc[3]['Quantity_2024']





print(kupac)
print('Ukupna godisnja kolicina je:' + str(kolicina))
