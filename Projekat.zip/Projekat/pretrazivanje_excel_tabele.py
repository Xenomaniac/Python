import pandas as pd

# Load the Excel file
df = pd.read_excel("high.xlsx", "Pareto")

# Find the row where the 'Customer' column contains 'Schaerer'
kupac = input("Unesite ime proizvodjaca koji vas zanima: ");
customer_row = df[df['Customer'].str.contains(kupac, na=False)]

# Check if any row was found
if not customer_row.empty:
    # Get the 'Customer' and 'Quantity_2024' values
    kupac = customer_row['Customer'].values[0]
    kolicina = customer_row['Quantity_2024'].values[0]

    # Print the results
    print(f"Customer: {kupac}")
    print(f"Quantity: {kolicina}")
else:
    print("Customer 'Schaerer' not found.")
